@echo off
setlocal
title SmartHRM Cloud Biometric Local Agent
color 0B

echo ========================================================
echo        SmartHRM Cloud Biometric Sync Agent
echo ========================================================
echo.

cd /d "%~dp0"

:: 1. Check for Embedded Node or System Node
if exist "bin\node.exe" (
    set "PATH=%~dp0bin;%PATH%"
) else if exist "..\distribution\bin\node.exe" (
    set "PATH=%~dp0..\distribution\bin;%PATH%"
)

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js engine not found.
    echo Please make sure the 'bin' folder contains node.exe.
    pause
    exit /b 1
)

:: 2. Launch Agent & Open Cloud Software
echo Starting SmartHRM Cloud Biometric Agent...
start https://app.creativeboxbd.com/admin/attendance
node agent.js
pause

