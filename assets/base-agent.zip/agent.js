/**
 * SmartHRM Biometric Cloud Gateway Agent
 * ----------------------------------------------------
 * Reads punches from local LAN Hikvision/ZKTeco biometric terminals
 * and securely relays them in real-time to the SmartHRM Cloud Backend.
 */

const https = require("https");
const http = require("http");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const CONFIG_FILE = path.join(process.cwd(), "config.json");

// Default Configuration
const DEFAULT_CONFIG = {
  cloudApiUrl: "https://secure-api.creativeboxbd.com",
  deviceIp: "192.168.68.69",
  devicePort: 443,
  deviceUsername: "admin",
  devicePassword: "",
  deviceSerialNumber: "", // If empty, agent auto-detects from device
  pollIntervalSeconds: 10,
};

function loadConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG, null, 2), "utf8");
    console.log("[Setup] Generated default config.json. Please configure credentials if needed.");
    return DEFAULT_CONFIG;
  }
  try {
    return { ...DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8")) };
  } catch (e) {
    console.error("[Error] Failed to read config.json:", e.message);
    return DEFAULT_CONFIG;
  }
}

const config = loadConfig();

function buildDigestHeader(method, uri, user, pass, authHeader) {
  const parts = {};
  authHeader.replace(/^Digest\s+/, "").split(/,\s*/).forEach((p) => {
    const idx = p.indexOf("=");
    if (idx !== -1) parts[p.slice(0, idx).trim()] = p.slice(idx + 1).replace(/"/g, "").trim();
  });
  const realm = parts.realm || "";
  const nonce = parts.nonce || "";
  const qop = parts.qop || "";
  const cnonce = crypto.randomBytes(8).toString("hex");
  const nc = "00000001";
  const ha1 = crypto.createHash("md5").update(`${user}:${realm}:${pass}`).digest("hex");
  const ha2 = crypto.createHash("md5").update(`${method}:${uri}`).digest("hex");
  if (qop.includes("auth")) {
    const response = crypto.createHash("md5").update(`${ha1}:${nonce}:${nc}:${cnonce}:auth:${ha2}`).digest("hex");
    return `Digest username="${user}", realm="${realm}", nonce="${nonce}", uri="${uri}", qop=auth, nc=${nc}, cnonce="${cnonce}", response="${response}"`;
  } else {
    const response = crypto.createHash("md5").update(`${ha1}:${nonce}:${ha2}`).digest("hex");
    return `Digest username="${user}", realm="${realm}", nonce="${nonce}", uri="${uri}", response="${response}"`;
  }
}

function makeDeviceRequest(method, reqPath, bodyStr = null) {
  return new Promise((resolve) => {
    const bodyBuf = bodyStr ? Buffer.from(bodyStr) : null;
    const headers = { "Content-Type": "application/json" };
    if (bodyBuf) headers["Content-Length"] = bodyBuf.length;
    else headers["Content-Length"] = 0;

    const isTls = Number(config.devicePort) === 443 || String(config.devicePort) === "443" || !config.devicePort;
    const transport = isTls ? https : http;

    const req1 = transport.request(
      {
        hostname: config.deviceIp,
        port: config.devicePort || (isTls ? 443 : 80),
        path: reqPath,
        method,
        rejectUnauthorized: false,
        timeout: 6000,
        headers,
      },
      (res1) => {
        const drain = (r) => { r.resume(); };
        if (res1.statusCode === 401 && res1.headers["www-authenticate"]) {
          drain(res1);
          const digest = buildDigestHeader(method, reqPath, config.deviceUsername, config.devicePassword, res1.headers["www-authenticate"]);
          const authHeaders = { ...headers, Authorization: digest };
          const req2 = transport.request(
            {
              hostname: config.deviceIp,
              port: config.devicePort || (isTls ? 443 : 80),
              path: reqPath,
              method,
              rejectUnauthorized: false,
              timeout: 7000,
              headers: authHeaders,
            },
            (res2) => {
              const chunks = [];
              res2.on("data", (c) => chunks.push(c));
              res2.on("end", () => resolve(Buffer.concat(chunks)));
            }
          );
          req2.on("error", () => resolve(null));
          req2.on("timeout", () => { req2.destroy(); resolve(null); });
          if (bodyBuf) req2.write(bodyBuf);
          req2.end();
        } else if (res1.statusCode === 200) {
          const chunks = [];
          res1.on("data", (c) => chunks.push(c));
          res1.on("end", () => resolve(Buffer.concat(chunks)));
        } else {
          drain(res1);
          resolve(null);
        }
      }
    );
    req1.on("error", () => resolve(null));
    req1.on("timeout", () => { req1.destroy(); resolve(null); });
    if (bodyBuf) req1.write(bodyBuf);
    req1.end();
  });
}

function sendToCloud(payload) {
  return new Promise((resolve, reject) => {
    try {
      const url = new URL(config.cloudApiUrl);
      const isHttps = url.protocol === "https:";
      const transport = isHttps ? https : http;
      const dataStr = JSON.stringify(payload);

      const req = transport.request(
        {
          hostname: url.hostname,
          port: url.port || (isHttps ? 443 : 80),
          path: "/api/devices/webhook/push-log",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(dataStr),
          },
          timeout: 8000,
        },
        (res) => {
          let buf = "";
          res.on("data", (c) => (buf += c));
          res.on("end", () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              resolve(true);
            } else {
              console.warn(`[Cloud Notice] Status ${res.statusCode}: ${buf.slice(0, 100)}`);
              resolve(false);
            }
          });
        }
      );
      req.on("error", (e) => {
        console.warn("[Cloud Connection Error]", e.message);
        resolve(false);
      });
      req.on("timeout", () => {
        req.destroy();
        resolve(false);
      });
      req.write(dataStr);
      req.end();
    } catch (e) {
      console.warn("[URL Error]", e.message);
      resolve(false);
    }
  });
}

let lastProcessedSerial = 0;

async function syncCycle() {
  try {
    // 1. Probe total matches on device
    const probePath = "/ISAPI/AccessControl/AcsEvent?format=json";
    const probeBody = JSON.stringify({
      AcsEventCond: {
        searchID: "agent_probe",
        searchResultPosition: 0,
        maxResults: 1,
        major: 0,
        minor: 0,
      },
    });

    const probeBuf = await makeDeviceRequest("POST", probePath, probeBody);
    if (!probeBuf) {
      console.log(`[Offline] Terminal ${config.deviceIp} unreachable.`);
      return;
    }

    let probeJson = null;
    try { probeJson = JSON.parse(probeBuf.toString()); } catch { return; }
    const totalMatches = Number(probeJson?.AcsEvent?.totalMatches || 0);

    if (lastProcessedSerial === 0) {
      // First boot: check recent 40 events
      lastProcessedSerial = Math.max(0, totalMatches - 40);
    }

    if (totalMatches <= lastProcessedSerial) {
      return; // No new punches
    }

    // Fetch new events
    const fetchBody = JSON.stringify({
      AcsEventCond: {
        searchID: "agent_fetch",
        searchResultPosition: lastProcessedSerial,
        maxResults: Math.min(100, totalMatches - lastProcessedSerial + 5),
        major: 0,
        minor: 0,
      },
    });

    const fetchBuf = await makeDeviceRequest("POST", probePath, fetchBody);
    if (!fetchBuf) return;

    let fetchJson = null;
    try { fetchJson = JSON.parse(fetchBuf.toString()); } catch { return; }
    const events = fetchJson?.AcsEvent?.InfoList || [];

    for (const ev of events) {
      if (ev.serialNo && ev.serialNo > lastProcessedSerial) {
        lastProcessedSerial = ev.serialNo;
      }

      // Filter only genuine valid authentication (75: Face, 38: Fingerprint, 1: Card)
      // Exclude 104 (Anti-Spoofing failed)
      if (ev.major === 5 && (ev.minor === 75 || ev.minor === 38 || ev.minor === 1) && ev.employeeNoString) {
        const mode = (ev.minor === 38 || ev.minor === 1) ? "FINGERPRINT" : "FACE_SCAN";
        const logMsg = `Emp: ${ev.employeeNoString} (${ev.name || "Unknown"}) Mode: ${mode} Time: ${ev.time}`;
        console.log(`[Punch Detected] ${logMsg}`);
        addRecentLog(`✔ ${logMsg}`);

        await sendToCloud({
          deviceSerialNumber: config.deviceSerialNumber || "HIK-TERMINAL-01",
          employeeId: String(ev.employeeNoString).trim(),
          punchTime: ev.time,
          verificationMode: mode,
          punchType: "CHECK_IN",
        });
      }
    }
  } catch (err) {
    console.error("[Agent Error]", err.message);
  }
}

console.log("====================================================");
console.log("      SmartHRM Cloud Biometric Agent Running        ");
console.log("====================================================");
console.log(`Connecting to Device: https://${config.deviceIp}`);
console.log(`Cloud Server:         ${config.cloudApiUrl}`);
console.log(`Poll Frequency:       Every ${config.pollIntervalSeconds} seconds`);
console.log("----------------------------------------------------");

const recentLogs = [];

function addRecentLog(msg) {
  const ts = new Date().toLocaleTimeString();
  recentLogs.unshift(`[${ts}] ${msg}`);
  if (recentLogs.length > 20) recentLogs.pop();
}

// Built-in Lightweight Local Web Server (No external dependencies)
const localServer = http.createServer((req, res) => {
  if (req.url === "/status") {
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(
      JSON.stringify({
        deviceIp: config.deviceIp,
        cloudApiUrl: config.cloudApiUrl,
        logs: recentLogs,
      })
    );
  }
  const htmlPath = path.join(__dirname, "dashboard.html");
  if (fs.existsSync(htmlPath)) {
    res.writeHead(200, { "Content-Type": "text/html" });
    return res.end(fs.readFileSync(htmlPath, "utf8"));
  }
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("SmartHRM Local Gateway Active.");
});

localServer.listen(4100, () => {
  console.log("Local Dashboard UI:   http://localhost:4100");
});

// Initial run
syncCycle();

// Polling interval
setInterval(syncCycle, (config.pollIntervalSeconds || 10) * 1000);

