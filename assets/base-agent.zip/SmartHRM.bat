@echo off
setlocal
title SmartHRM Enterprise Suite
color 0A

cd /d "%~dp0"

:: 1. Launch Biometric Sync Agent silently in background
start "SmartHRM-Gateway" /min cmd /c "if exist "bin\node.exe" (set "PATH=%~dp0bin;%PATH%") && node agent.js"

:: 2. Launch Dedicated Desktop Window using Edge/Chrome App Mode (Zero installation needed)
set "APP_URL=https://app.creativeboxbd.com/login"

if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="%APP_URL%" --window-size=1280,820
    exit /b 0
)

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="%APP_URL%" --window-size=1280,820
    exit /b 0
)

:: Fallback to default browser
start "" "%APP_URL%"
exit /b 0

